<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {
//Validating login
function __construct(){
parent::__construct();
if(!$this->session->userdata('uid'))
redirect('signin');
}
public function index(){
    $userfname = $this->session->userdata('fname');	
    $donation = $this->session->userdata('donation');
    
    $this->load->view('welcome',['firstname'=>$userfname,'contribution'=>$donation]);

    
}
function mypdf(){


	$this->load->library('pdf');


  	$this->pdf->load_view('mypdf');
  	$this->pdf->render();


  	$this->pdf->stream("welcome.pdf");
   }
}
