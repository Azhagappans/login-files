<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class fpdf_test extends CI_Controller{
    public function index(){
        $this->load->library('pdf_gen');

        $this->fpdf->SetFont('Arial','B','15');
        $this->fpdf->cell('40','10','My PDF');
        $this->fpdf->cell('10','40','Contribution to the user preferences must choose from the');    
        $this->fpdf->cell('10','60','previous content of time or money basis');    
        echo $this->fpdf->output('custompdf.pdf','I'); 
        $this->signin($firstname);
        echo $info = parse_str($_SERVER['info'], $_GET); 
        
    }
}